// leave.ts

import type { AppCtx } from '@/engine/types/controller.types.js';
import { MessageStyle } from '@/engine/constants/message-style.constants.js';
import type { EventMeta } from '@/engine/types/module-config.types.js';

export const meta: EventMeta = {
  name: 'leave',
  eventType: ['log:unsubscribe'],
  version: '1.0.0',
  author: 'John Lester',
  description: 'Sends a goodbye message when members leave the group',
};

export const onEvent = async ({ event, chat, bot }: AppCtx) => {
  try {
    const logMessageData = event['logMessageData'] as
      | Record<string, unknown>
      | undefined;
    const logMessageBody = event['logMessageBody'] as string | undefined;
    const author = event['author'] as string | undefined;

    const leftId = String(logMessageData?.['leftParticipantFbId'] ?? '');

    const botId = await bot.getID();
    if (leftId === botId) return;

    const wasRemoved = Boolean(author && author !== leftId);

    const message = logMessageBody
      ? `👋 ${logMessageBody}`
      : wasRemoved
        ? '👋 **A member has been removed** from the group.'
        : '👋 **A member has left** the group.'

    await chat.replyMessage({
      style: MessageStyle.MARKDOWN,
      message,
    });
  } catch (err) {
    console.error('❌ leave event handler failed:', err);
  }
};