/**
 * /daily — Daily Reward Command
 *
 * Claims a daily reward once every 24 hours per user per session.
 * Tracks cooldown and consecutive-day streak inside the user's "daily"
 * collection on their bot_users_session row — no separate DB table needed.
 *
 * Collection schema (stored in bot_users_session.data → "daily" key):
 *   {
 *     lastClaim:  number   — Unix timestamp (ms) of the most recent claim
 *     streak:     number   — consecutive days claimed (resets on miss)
 *   }
 *
 * Streak bonus: +10 coins per additional day, capped at 6 bonus days (day 7 = +60).
 * Coin crediting is intentionally kept as a display-only reward until a coin
 * system is added — this command demonstrates the collection API end-to-end.
 */

import type { AppCtx } from '@/engine/types/controller.types.js';
import { Role } from '@/engine/constants/role.constants.js';
import { MessageStyle } from '@/engine/constants/message-style.constants.js';
import { ButtonStyle } from '@/engine/constants/button-style.constants.js';
import { hasNativeButtons } from '@/engine/utils/ui-capabilities.util.js';
import type { CommandMeta } from '@/engine/types/module-config.types.js';
import { formatCoins } from '@/engine/lib/currencies.lib.js';

export const meta: CommandMeta = {
  name: 'daily',
  aliases: [] as string[],
  version: '1.0.0',
  role: Role.ANYONE,
  author: 'John Lester',
  description: 'Claim your daily reward (resets every 24 hours)',
  category: 'Economy',
  usage: '',
  cooldown: 5,
  hasPrefix: true,
};

/** 24-hour cooldown window in milliseconds. */
const COOLDOWN_MS = 24 * 60 * 60 * 1000;

/** Base coins rewarded on every claim. */
const BASE_COINS = 200;

/** Additional coins per streak day beyond the first, capped at MAX_STREAK_BONUS_DAYS. */
const MAX_STREAK_BONUS_DAYS = 6;
const COINS_PER_STREAK_DAY = 10;

const BUTTON_ID = { check_balance: 'check_balance', back: 'back' } as const;

// Natural economy-loop UX: after claiming, the most common next question is
// "how many coins do I have now?" — surface it as a single button click.
export const button = {
  [BUTTON_ID.check_balance]: {
    label: '💰 My Balance',
    style: ButtonStyle.SECONDARY,
    onClick: async ({ chat, event, native, button, currencies }: AppCtx) => {
      const senderID = event['senderID'] as string | undefined;
      // Back button lets the user return to the daily claim status without retyping the command
      const backId = button.generateID({ id: BUTTON_ID.back });
      if (!senderID) {
        await chat.editMessage({
          style: MessageStyle.MARKDOWN,
          message_id_to_edit: event['messageID'] as string,
          message: '❌ Could not identify your user ID on this platform.',
          ...(hasNativeButtons(native.platform) ? { button: [backId] } : {}),
        });
        return;
      }
      // currencies.getMoney returns 0 when the user has no money collection yet — no early-return needed
      const coins = await currencies.getMoney(senderID);
      await chat.editMessage({
        style: MessageStyle.MARKDOWN,
        message_id_to_edit: event['messageID'] as string,
        message: `💰 **Your balance:** ${formatCoins(coins)} coins`,
        ...(hasNativeButtons(native.platform) ? { button: [backId] } : {}),
      });
    },
  },
  // Returns to the daily claim status view — creates a balance ↔ daily-status toggle loop
  [BUTTON_ID.back]: {
    label: '⬅ Back',
    style: ButtonStyle.SECONDARY,
    onClick: async ({
      chat,
      event,
      db,
      native,
      button,
      prefix = '',
    }: AppCtx) => {
      const senderID = event['senderID'] as string | undefined;
      // Regenerate check_balance so the user can toggle back to balance from this view
      const balId = button.generateID({ id: BUTTON_ID.check_balance });
      if (!senderID) {
        await chat.editMessage({
          style: MessageStyle.MARKDOWN,
          message_id_to_edit: event['messageID'] as string,
          message: '❌ Could not identify your user ID on this platform.',
          ...(hasNativeButtons(native.platform) ? { button: [balId] } : {}),
        });
        return;
      }
      const userColl = db.users.collection(senderID);
      if (!(await userColl.isCollectionExist('money'))) {
        await chat.editMessage({
          style: MessageStyle.MARKDOWN,
          message_id_to_edit: event['messageID'] as string,
          message: `📅 You haven't claimed \`${prefix}daily\` yet — your first reward is waiting!`,
          ...(hasNativeButtons(native.platform) ? { button: [balId] } : {}),
        });
        return;
      }
      const money = await userColl.getCollection('money');
      const lastClaim = (await money.get('lastClaim')) as number | undefined;
      // streak is stored in the same money collection written by onCommand
      const streak = ((await money.get('streak')) as number | undefined) ?? 0;
      const COOLDOWN_MS = 24 * 60 * 60 * 1000;
      if (!lastClaim || Date.now() - lastClaim >= COOLDOWN_MS) {
        await chat.editMessage({
          style: MessageStyle.MARKDOWN,
          message_id_to_edit: event['messageID'] as string,
          message: [
            `📅 Your daily reward is **ready**! Use \`${prefix}daily\` to claim.`,
            `🔥 Streak: **${streak} day(s)**`,
          ].join('\n'),
          ...(hasNativeButtons(native.platform) ? { button: [balId] } : {}),
        });
      } else {
        const remaining = COOLDOWN_MS - (Date.now() - lastClaim);
        const hours = Math.floor(remaining / (1000 * 60 * 60));
        const minutes = Math.floor(
          (remaining % (1000 * 60 * 60)) / (1000 * 60),
        );
        await chat.editMessage({
          style: MessageStyle.MARKDOWN,
          message_id_to_edit: event['messageID'] as string,
          message: [
            `⏰ Next daily claim in: **${hours}h ${minutes}m**`,
            `🔥 Streak: **${streak} day(s)**`,
          ].join('\n'),
          ...(hasNativeButtons(native.platform) ? { button: [balId] } : {}),
        });
      }
    },
  },
};

export const onCommand = async ({
  chat,
  event,
  db,
  native,
  button,
  currencies,
}: AppCtx): Promise<void> => {
  const senderID = event['senderID'] as string | undefined;

  if (!senderID) {
    await chat.replyMessage({
      style: MessageStyle.MARKDOWN,
      message: '❌ Could not identify your user ID on this platform.',
    });
    return;
  }

  // Retrieve the collection manager bound to this user's bot_users_session row.
  // db.users.collection is pre-scoped to (sessionOwnerUserId, platform, sessionId)
  // so the command only needs to supply the platform user ID (senderID).
  const userColl = db.users.collection(senderID);

  if (!(await userColl.isCollectionExist('money'))) {
    await userColl.createCollection('money');
  }

  const daily = await userColl.getCollection('money');

  const lastClaim = (await daily.get('lastClaim')) as number | undefined;
  const now = Date.now();

  // ── Cooldown check ────────────────────────────────────────────────────────
  if (lastClaim !== undefined && now - lastClaim < COOLDOWN_MS) {
    const remaining = COOLDOWN_MS - (now - lastClaim);
    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((remaining % (1000 * 60)) / 1000);
    const pad = (n: number) => String(n).padStart(2, '0');

    await chat.replyMessage({
      style: MessageStyle.MARKDOWN,
      message: [
        "⏰ You've already claimed today's reward!",
        `Come back in: ${hours}h ${pad(minutes)}m ${pad(seconds)}s`,
      ].join('\n'),
    });
    return;
  }

  // ── Streak calculation ────────────────────────────────────────────────────
  // Streak increments only when claimed on consecutive calendar days.
  // A missed day resets the streak back to 1 rather than 0 — the current
  // claim always counts as day 1 even after a break.
  const currentStreak =
    ((await daily.get('streak')) as number | undefined) ?? 0;
  const lastClaimDate =
    lastClaim !== undefined ? new Date(lastClaim).toDateString() : null;
  const yesterdayDate = new Date(now - 86_400_000).toDateString();
  const newStreak = lastClaimDate === yesterdayDate ? currentStreak + 1 : 1;

  // ── Compute reward ────────────────────────────────────────────────────────
  // Bonus scales with streak but caps so long-time users don't get unbounded rewards.
  const streakBonusDays = Math.min(newStreak - 1, MAX_STREAK_BONUS_DAYS);
  const streakBonus = streakBonusDays * COINS_PER_STREAK_DAY;
  const totalCoins = BASE_COINS + streakBonus;

  // ── Persist state — write streak before coins message so state is durable even
  // if the message send fails. Two set calls instead of one update call to keep
  //    intent explicit and avoid accidental merge of the whole collection.
  await daily.set('lastClaim', now);
  await daily.set('streak', newStreak);
  // Persist earned coins so /balance can read the running total from the money collection.
  await currencies.increaseMoney({ user_id: senderID, money: totalCoins });

  // Button offered only on platforms with native components — encourages the economy
  // loop (daily → balance check) without adding text-menu noise on FB Messenger.

  // ── Respond ───────────────────────────────────────────────────────────────
  const streakLine =
    newStreak > 1
      ? `🔥 Streak: **${newStreak} days** (+${streakBonus} bonus coins)`
      : '🔥 Streak: **1 day** (maintain a streak for bonus coins!)';

  await chat.replyMessage({
    style: MessageStyle.MARKDOWN,
    message: [
      '✅ Daily reward claimed!',
      `💰 Coins: **+${totalCoins}**`,
      streakLine,
      '⏰ Come back in 24 hours to keep your streak going!',
    ].join('\n'),
    ...(hasNativeButtons(native.platform)
      ? { button: [button.generateID({ id: BUTTON_ID.check_balance })] }
      : {}),
  });
};
