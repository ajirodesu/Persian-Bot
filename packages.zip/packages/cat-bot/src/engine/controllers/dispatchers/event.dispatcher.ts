/**
 * Event Dispatcher — fans out to registered event handlers for a given type.
 *
 * Simple, reusable pattern: any module that registers for an event type via
 * meta.eventType[] gets its onEvent handler called in registration order.
 */

import type {
  EventModuleMap,
  BaseCtx,
} from '@/engine/types/controller.types.js';
// Platform filter — enforces meta.platform[] declared by each event module
import { isPlatformAllowed } from '@/engine/modules/platform/platform-filter.util.js';
// Event registry check — honours bot admin toggle decisions in bot_session_events
import { isEventEnabled } from '@/engine/modules/session/bot-session-events.repo.js';
// Middleware infrastructure — wires the onEvent lifecycle hook introduced by on-event.middleware.ts
import {
  middlewareRegistry,
  runMiddlewareChain,
} from '@/engine/lib/middleware.lib.js';
import type { OnEventCtx } from '@/engine/types/middleware.types.js';

/**
 * Fires every registered handler for the given unified event type.
 */
export async function dispatchEvent(
  eventModules: EventModuleMap,
  eventType: string,
  ctx: BaseCtx,
): Promise<void> {
  // Extract platform once — avoids a repeated cast inside the handler loop
  const platform = ctx.native.platform;
  // Hoist session identity outside the loop — same cost regardless of handler count
  const sessionUserId = ctx.native.userId ?? '';
  const sessionId = ctx.native.sessionId ?? '';
  const handlers = eventModules.get(eventType) ?? [];
  for (const mod of handlers) {
    if (typeof mod['onEvent'] === 'function') {
      // Skip modules that explicitly exclude this platform via meta.platform[]
      if (!isPlatformAllowed(mod, platform)) continue;
      // Skip modules disabled by the bot admin — keyed by meta.name, not eventType,
      // so the dashboard label matches the module name the user recognises ('join', 'leave').
      if (sessionUserId && sessionId) {
        const modName = (
          (mod['meta'] as { name?: string } | undefined)?.name ?? ''
        ).toLowerCase();
        if (
          modName &&
          !(await isEventEnabled(sessionUserId, platform, sessionId, modName))
        )
          continue;
      }
      // Build a per-handler context and run the onEvent middleware chain.
      // Each mod gets its own chain invocation so middleware (e.g. enforceWarnBan) can
      // gate specific modules by name without short-circuiting the entire fan-out — other
      // handlers on the same eventType (e.g. checkwarn.ts) continue to execute normally.
      const eventCtx: OnEventCtx = { ...ctx, mod, eventType };
      await runMiddlewareChain<OnEventCtx>(
        middlewareRegistry.getOnEvent(),
        eventCtx,
        async () => {
          try {
            await (mod['onEvent'] as (ctx: BaseCtx) => unknown)(ctx);
          } catch (err: unknown) {
            console.error(`❌ Event handler "${eventType}" failed`, err);
          }
        },
      );
    }
  }
}
