/**
 * onChat Middleware — Cross-Cutting Message Concerns + Thread/User Sync
 *
 * Runs ONCE per incoming message BEFORE the onChat fan-out to individual command modules.
 * Provides the injection point for global message-level concerns that apply to every
 * message regardless of whether it triggers a command.
 *
 * ── Database Sync ─────────────────────────────────────────────────────────────
 * On each message, this middleware checks bot_threads and bot_users for the
 * current (platform, threadID) and (platform, senderID) pairs. If either is
 * absent, it fetches from the platform API and upserts:
 *
 *   1. Thread sync  → ctx.thread.getInfo(threadID) → upsert bot_threads
 *                     + loops participantIDs → upsert each into bot_users
 *   2. Sender check → if senderID still absent after thread sync (e.g. FB Page 1:1,
 *                     Telegram private DM where participantIDs is empty),
 *                     fetches directly via ctx.user.getInfo(senderID)
 *
 * Sync errors are caught and logged — they must never block the command pipeline.
 *
 * Extension points: rate limiting, audit logging, bot-mention filtering, spam detection.
 * Add middleware via use.onChat([yourMiddleware]) in src/middleware/index.ts.
 */

import type {
  MiddlewareFn,
  OnChatCtx,
} from '@/engine/types/middleware.types.js';
import { syncThreadAndParticipants } from '@/engine/services/threads.service.js';
import { syncUser } from '@/engine/services/users.service.js';
import {
  getThreadSessionUpdatedAt,
  upsertThreadSession,
} from '@/engine/repos/threads.repo.js';
import {
  getUserSessionUpdatedAt,
  upsertUserSession,
} from '../repos/users.repo.js';

// ── Resync policy ────────────────────────────────────────────────────────────
// Single named constant so the entire hourly-resync behaviour is controlled here.
// Changing this value is the only edit needed to adjust the refetch frequency.
const SYNC_INTERVAL_MS = 60 * 60 * 1000; // 1 hour

/**
 * Syncs the current thread and message sender into the database on first encounter,
 * and re-syncs when their session rows are older than SYNC_INTERVAL_MS (1 hour),
 * then calls next() to continue the middleware chain.
 *
 * The DB check (findUnique selecting only id) is a cheap index-only read. On
 * subsequent messages within the 1-hour window only a lightweight timestamp
 * read occurs — the overhead is negligible in steady state.
 */
export const chatPassthrough: MiddlewareFn<OnChatCtx> = async function (
  ctx,
  next,
): Promise<void> {
  const platform = ctx.native.platform;
  const { logger } = ctx;
  // Resolve session identity from native context — set by the platform transport layer from
  // session/{userId}/{platform}/{sessionId}/ directory at boot time.
  const sessionUserId = ctx.native.userId ?? '';
  const sessionId = ctx.native.sessionId ?? '';
  // senderID is the standard field on message events; fall back to userID for
  // edge cases (some reaction-shaped events that still reach this middleware)
  const senderID = (ctx.event['senderID'] ??
    ctx.event['userID'] ??
    '') as string;
  const threadID = (ctx.event['threadID'] ?? '') as string;

  // All four fields required — partial context can't produce a valid composite session key.
  // Platform listeners that do not yet set userId/sessionId in native context skip sync entirely.
  if (platform && threadID && sessionUserId && sessionId) {
    try {
      // Snapshot before the parallel await so both stale checks use a consistent reference
      // rather than two Date.now() calls separated by a DB round-trip.
      const now = Date.now();
      // Thread and sender staleness reads are independent DB queries — running them in parallel
      // eliminates one full DB round-trip from every message's hot path (they were sequential).
      // senderID guard: when senderID is absent (e.g. some system events) we resolve null as the
      // placeholder so Promise.all sees a uniform element type; the if (senderID) block below
      // ensures we never act on the placeholder value.
      const [threadUpdatedAt, senderUpdatedAt] = await Promise.all([
        getThreadSessionUpdatedAt(sessionUserId, platform, sessionId, threadID),
        senderID
          ? getUserSessionUpdatedAt(
              sessionUserId,
              platform,
              sessionId,
              senderID,
            )
          : Promise.resolve(null as Date | null),
      ]);
      // Null means the thread has never been synced; a timestamp older than SYNC_INTERVAL_MS means the
      // cached metadata (name, member count, admin list) may have drifted from the platform's state.
      const threadStale =
        threadUpdatedAt === null ||
        now - threadUpdatedAt.getTime() > SYNC_INTERVAL_MS;
      if (threadStale) {
        // Log new vs update before the optimistic stamp so the event is always
        // recorded even if the subsequent upsertThreadSession call is skipped.
        if (threadUpdatedAt === null) {
          logger.info(`[database] New thread: ${threadID}`);
        } else {
          logger.info(`[database] Update thread: ${threadID}`);
        }
        // Optimistic timestamp: stamp lastUpdatedAt immediately when the session row already
        // exists so concurrent messages racing the background API fetch don't each detect
        // staleness and each fire redundant syncs.
        // WHY: Safe because the adapter enforces a FK from bot_thread_session → bot_thread.
        // For Discord, upsertThreadSession intelligently intercepts and routes to bot_discord_server_session
        // if the channel belongs to a guild, or bot_threads_session if it's a DM.
        if (threadUpdatedAt !== null) {
          void upsertThreadSession(
            sessionUserId,
            platform,
            sessionId,
            threadID,
          );
        }
        // Fire-and-forget — bot pipeline advances immediately; the platform API fetch and
        // subsequent DB writes run in the background. syncThreadAndParticipants will call
        // upsertThreadSession again on completion, refreshing the timestamp a second time.
        void syncThreadAndParticipants(ctx, threadID, sessionUserId, sessionId);
      }

      // Always check the sender explicitly — they may not appear in participantIDs on
      // FB Page 1:1 (participant list only contains the page bot) or Telegram private DMs.
      // Also re-sync if the sender's session row is stale even when the thread row is fresh.
      // senderUpdatedAt was fetched in parallel with threadUpdatedAt above.
      if (senderID) {
        const senderStale =
          senderUpdatedAt === null ||
          now - senderUpdatedAt.getTime() > SYNC_INTERVAL_MS;
        if (senderStale) {
          // Log new vs update before the optimistic stamp — same rationale as the thread block above.
          if (senderUpdatedAt === null) {
            logger.info(`[database] New user: ${senderID}`);
          } else {
            logger.info(`[database] Update user: ${senderID}`);
          }
          // Same optimistic stamp pattern as thread: only when the row exists to avoid a
          // FK violation on the very first time this user is seen in this session.
          if (senderUpdatedAt !== null) {
            void upsertUserSession(
              sessionUserId,
              platform,
              sessionId,
              senderID,
            );
          }
          // Fire-and-forget — syncUser calls upsertUserSession again on completion.
          void syncUser(ctx, senderID, sessionUserId, sessionId);
        }
      }
    } catch (err: unknown) {
      // Sync failure must never interrupt the message pipeline; log and continue
      logger.warn('⚠️ [on-chat] DB sync failed — continuing pipeline', {
        error: err,
      });
    }
  }

  await next();
};

export const chatLogThread: MiddlewareFn<OnChatCtx> = async function (
  ctx,
  next,
): Promise<void> {
  const { threadID, senderID, message } = ctx.event;
  const { logger } = ctx;
  const { platform } = ctx.native;

  // Guard to prevent logging 'undefined' on non-text events (e.g. photo attachments without caption)
  if (message) {
    logger.info(`[${platform}] ${threadID} | ${senderID}: ${message}`);
  }
  await next();
};
