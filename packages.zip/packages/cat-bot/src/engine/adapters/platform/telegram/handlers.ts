/**
 * Telegram — Telegraf Handler Registrations
 *
 * Registers all Telegraf update handlers that emit unified events on the
 * platform emitter. Each handler normalizes its raw Telegram context into
 * the unified event contract before emitting.
 *
 * Separated from listener.ts because handlers are the most frequently modified
 * concern (adding new event types, adjusting normalisation) and benefit from
 * being independently testable without constructing the full listener factory.
 *
 * Handlers attached:
 *   'message'           → emit 'message' or 'message_reply'
 *   'new_chat_members'  → emit 'event' (log:subscribe)
 *   'left_chat_member'  → emit 'event' (log:unsubscribe)
 *   'message_reaction'  → emit 'message_reaction'
 *   'callback_query'    → emit 'button_action'
 */
import type { EventEmitter } from 'events';
import type { Telegraf } from 'telegraf';
import { message } from 'telegraf/filters';
import type { Message } from 'telegraf/types';
import { Platforms } from '@/engine/modules/platform/platform.constants.js';
import { EventType } from '@/engine/adapters/models/enums/index.js';
import { createTelegramApi } from './wrapper.js';
import {
  normalizeTelegramEvent,
  normalizeNewChatMembersEvent,
  normalizeLeftChatMemberEvent,
  normalizeTelegramReactionEvent,
  resolveAttachmentUrls,
} from './utils/helper.util.js';

/**
 * Attaches all Telegraf update handlers to the given bot instance.
 * Each handler normalizes its context and emits a typed event on the emitter.
 *
 * IMPORTANT: Must be called BEFORE bot.launch() per Telegraf documentation.
 */
export function attachHandlers(
  bot: Telegraf,
  emitter: EventEmitter,
  prefix: string,
  userId: string,
  sessionId: string,
): void {
  // ── Service message handlers MUST be registered before the general 'message' handler ───
  // Telegraf uses Koa-style middleware: the first registered handler that omits next() terminates
  // the chain. bot.on('message') matches ALL message-type updates (including service messages).
  // If it were first and returned without calling next(), these specific handlers would never fire.

  // ── Member join → emit 'event' (log:subscribe) ────────────────────────────
  bot.on(message('new_chat_members'), async (ctx) => {
    const api = createTelegramApi(ctx);
    const event = normalizeNewChatMembersEvent(ctx);
    const native = { platform: Platforms.Telegram, userId, sessionId, ctx };
    emitter.emit(EventType.EVENT, { api, event, native, prefix });
  });

  // ── Member leave → emit 'event' (log:unsubscribe) ─────────────────────────
  bot.on(message('left_chat_member'), async (ctx) => {
    const api = createTelegramApi(ctx);
    const event = normalizeLeftChatMemberEvent(ctx);
    const native = { platform: Platforms.Telegram, userId, sessionId, ctx };
    emitter.emit(EventType.EVENT, { api, event, native, prefix });
  });

  // ── Message handler → emit 'message' or 'message_reply' ──────────────────
  // Bare 'message' update type catches ALL Telegram message kinds: text, photo,
  // video, audio, document, sticker, voice, video_note, animation. The previous
  // message('text') filter silently dropped every attachment-only message.
  bot.on('message', async (ctx) => {
    const msg = ctx.message as Message & {
      new_chat_members?: unknown[];
      left_chat_member?: unknown;
      reply_to_message?: Message;
    };
    // Service messages are handled by the specific handlers registered above (which fired first).
    // Guard retained as a safety net in case Telegram ever delivers them via an unexpected path.
    if (msg.new_chat_members || msg.left_chat_member) return;

    const rawText =
      ('text' in msg ? msg.text : undefined) ??
      ('caption' in msg ? msg.caption : undefined) ??
      '';
    const rawArgs = rawText.trim().split(/\s+/).filter(Boolean);
    const api = createTelegramApi(ctx);
    const event = normalizeTelegramEvent(ctx, rawArgs);

    // Resolve file_id → CDN URL for outer message and replied-to message attachments.
    // Telegram Bot API never embeds direct URLs — getFileLink() is the mandatory round-trip.
    // URLs are valid for ~1 hour per Bot API spec.
    await resolveAttachmentUrls(
      (event['attachments'] as Array<
        import('./utils/helper.util.js').TelegramAttachment
      >) ?? [],
      ctx.telegram,
    );
    const replyAtts = (
      event['messageReply'] as Record<string, unknown> | null
    )?.['attachments'] as Array<{ ID: string; url: string | null }> | undefined;
    if (replyAtts?.length) {
      await resolveAttachmentUrls(
        replyAtts as Array<import('./utils/helper.util.js').TelegramAttachment>,
        ctx.telegram,
      );
    }

    const native = { platform: Platforms.Telegram, userId, sessionId, ctx };
    // reply_to_message is set when the user taps "Reply" on an existing message
    const eventType = msg.reply_to_message
      ? EventType.MESSAGE_REPLY
      : EventType.MESSAGE;
    emitter.emit(eventType, { api, event, native, prefix });
  });

  // ── Message reaction → emit 'message_reaction' ───────────────────────────
  // Requires: (1) 'message_reaction' in allowedUpdates below, AND
  //           (2) bot must be a GROUP ADMINISTRATOR — non-admin bots never receive
  //               reaction updates regardless of allowedUpdates setting.
  bot.on('message_reaction', async (ctx) => {
    const api = createTelegramApi(ctx);
    const event = normalizeTelegramReactionEvent(ctx);
    const native = { platform: Platforms.Telegram, userId, sessionId, ctx };
    emitter.emit(EventType.MESSAGE_REACTION, { api, event, native, prefix });
  });

  // ── Inline keyboard button press → emit 'button_action' ─────────────────────
  // callback_query fires when a user taps an InlineKeyboardButton sent with callback_data.
  // answerCbQuery() MUST be called within ~10 s to dismiss the loading spinner — the call is
  // deliberately deferred to button.dispatcher so it can pass an alert message (show_alert=true)
  // for unauthorized button clicks before acknowledging the query.
  bot.on('callback_query', async (ctx) => {
    // Do NOT call ctx.answerCbQuery() here — button.dispatcher owns the call so it can show
    // a show_alert=true popup (private modal visible only to the button clicker) on scope failure.
    const api = createTelegramApi(ctx);
    const cbq = ctx.callbackQuery as {
      data?: string;
      message?: { chat: { id: number }; message_id: number };
      from: { id: number };
    };
    const event = {
      type: EventType.BUTTON_ACTION,
      platform: Platforms.Telegram,
      buttonId: cbq.data ?? '',
      threadID: String(cbq.message?.chat?.id ?? ''),
      senderID: String(cbq.from.id),
      messageID: String(cbq.message?.message_id ?? ''),
      timestamp: Date.now(),
    };
    const native = {
      platform: Platforms.Telegram,
      userId,
      sessionId,
      ctx,
      // Expose answerCbQuery so button.dispatcher can pass an alert text for unauthorized clicks
      // (show_alert=true renders a native modal popup visible only to the user who pressed the button)
      // or call with no arguments for a normal silent acknowledgement on authorized clicks.
      ack: (text?: string, showAlert?: boolean) =>
        ctx.answerCbQuery(text, {
          ...(showAlert !== undefined ? { show_alert: showAlert } : {}),
        }),
    };
    emitter.emit(EventType.BUTTON_ACTION, { api, event, native, prefix });
  });
}
